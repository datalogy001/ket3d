futurecall.controller('contactController', function ($scope, $location,$ionicSideMenuDelegate,$ionicSlideBoxDelegate, $ionicPopup,$ionicHistory,contactService,$interval) {
   
    $scope.contactList=[]  ;
    $scope.userSelectionList=[];

    $scope.contactPersonInit=function()
   {
    $scope.collectUserList= [];   
    var Promise = contactService.getContactList(window.localStorage.getItem('user_id'));
            Promise.then(function (res) {
               if(res.length > 0)
               {
                $scope.contactList= res;
               }
            }); 
   }
   
   $scope.contactVoice=function(id)
   {
    $location.url("main/callFutureIndv/"+id);
   }
  
  $scope.getMultipleUsers=function()
  {
    if($scope.collectUserList.length > 0)
    {
    $location.url("main/callFutureUserList/"+$scope.collectUserList);
    }else
    {
     $scope.errorAlertBoxAll("Please select one of the contact");   
    }
  }
  
  $scope.mergeUserList=function()
  {
        $scope.collectUserList= [];
        $('input[name="userSelectionList[]"]:checked').each(function () {
            $scope.collectUserList.push(this.value);
        });
    //  console.log("before"+JSON.stringify($scope.collectUserList));
  }
 
  
});




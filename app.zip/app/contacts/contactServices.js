futurecall.factory('contactService', function ($q, $http,AppConstant,$ionicLoading) {
  var futurecallFactory = {};
    var deferred = $q.defer();
    
      var _getContactList = function (user_id) {
     /*   $ionicLoading.show({
            content: '<i class="icon ion-loading-a"></i>',
            showBackdrop: false
        }); */
         return $http({method: "jsonp", url: AppConstant.ServerPath +"?callback=JSON_CALLBACK&param=getContactList&user_id=" + user_id}).then(function (result) {
           // $ionicLoading.hide();
            return result.data;
        });
      }    
      
     futurecallFactory.getContactList = _getContactList;
     
    return futurecallFactory;
});
futurecall.controller('messageController', function ($scope,$location,AppConstant,$timeout,$ionicPopup,$ionicHistory,messageService,$stateParams) {
    $scope.messageListInit=function()
   {
    $scope.testDate = new Date();
    $scope.receiverList=[]  ;
    $scope.sendList=[]  ;
    $scope.userIdLogin=window.localStorage.getItem('user_id');
    var Promise = messageService.getMessageList(window.localStorage.getItem('user_id'),$stateParams.userMsgList);
            Promise.then(function (res) {
                angular.forEach(res.sender, function(value, key){
                res.sender[key].recorded_date = new Date(res.sender[key].recorded_date.replace(/-/g,"/"));
                res.sender[key].created = new Date(res.sender[key].created.replace(/-/g,"/"));
                   } );   
                $scope.sendList= res.sender;
             //   alert(JSON.stringify($scope.sendList));
                //For receiver list
                
                angular.forEach(res.receiver, function(value, key){
                res.receiver[key].recorded_date = new Date(res.receiver[key].recorded_date.replace(/-/g,"/"));
                res.receiver[key].created = new Date(res.receiver[key].created.replace(/-/g,"/"));
                   } );   
                $scope.receiverList= res.receiver;
                 
                //End of code 
            }); 
   }
   
    $scope.updateSeenMessages=function(receiverId)
    {
     var PromiseSeen = messageService.updateSeenMessages(receiverId);
    }
   
   $scope.contactMessageListInit=function()
   {
    $scope.testDate = new Date();
    $scope.contactMessageList=[]  ;
    
    var Promise = messageService.getMessageList(window.localStorage.getItem('user_id'),$stateParams.contactMsgList);
            Promise.then(function (res) {
                angular.forEach(res.receiver, function(value, key){
                res.receiver[key].recorded_date = new Date(res.receiver[key].recorded_date.replace(/-/g,"/"));
                res.receiver[key].created = new Date(res.receiver[key].created.replace(/-/g,"/"));
                   } );   
                $scope.contactMessageList= res.receiver;
               
            }); 
   }
   
   $scope.voiceMsgInit=function()
   {
    //Init variables    
    $scope.userName="" ;
    $scope.recordDate="";
    $scope.recordMsg="";
    $scope.userNameHeader="";
    $scope.soundStatus=false;
    $scope.voiceMsg= ""; 
    $scope.audioDisabled=true;
    //End 
     $scope.userIdLogin=window.localStorage.getItem('user_id');
   var Promise = messageService.getVoiceMsg($stateParams.recordMsgId,$stateParams.type);
            Promise.then(function (res) {
                if(res.length > 0)
                {
                 $scope.userName=res[0].firstName ;
                 $scope.userId=res[0].sender_id ;
                 $scope.recordDate=new Date(res[0].recorded_date.replace(/-/g,"/"));
                 $scope.recordMsg=res[0].recorded_msg;
                }
                 $timeout(function() {
                     if($scope.userId ==$scope.userIdLogin )
                         $scope.userNameHeader= "Myself"; 
                       else
                       $scope.userNameHeader= res[0].firstName; 
         }, 500);
  
            });     
   }
   
   $scope.recordVoice=function (userId)
   {
     $location.url("main/callFutureIndv/"+userId)  ;
   }
   
   $scope.listenMsg=function()
   {
    $scope.soundPath=AppConstant.AudioFolderPath+$scope.recordMsg;
    $scope.voiceMsg = new Media($scope.soundPath);
    $scope.voiceMsg.play();
    $scope.audioDisabled=false;
    }
   
   $scope.stopAudio=function()
   {
     $scope.voiceMsg.stop();   
     $scope.audioDisabled=true;
     
   }
    
    $scope.$on('$ionicView.enter', function () {
     $scope.audioDisabled=true;
    });
    
    $scope.$on('$ionicView.leave', function () {
        $scope.voiceMsg.stop();   
        });
   
});




futurecall.factory('messageService', function ($q, $http,AppConstant,$ionicLoading) {
  var futurecallFactory = {};
    var deferred = $q.defer();
    
      var _getMessageList = function (user_id,friendId) {
        $ionicLoading.show({
            content: '<i class="icon ion-loading-a"></i>',
            showBackdrop: false
        });
         return $http({method: "jsonp", url: AppConstant.ServerPath +"?callback=JSON_CALLBACK&param=getMessageList&user_id=" + user_id+"&friendId="+friendId}).then(function (result) {
             
            $ionicLoading.hide();
            return result.data;
        });
      }   
       var _getVoiceMsg = function (recorded_id,type) {
        $ionicLoading.show({
            content: '<i class="icon ion-loading-a"></i>',
            showBackdrop: false
        });
         return $http({method: "jsonp", url: AppConstant.ServerPath +"?callback=JSON_CALLBACK&param=getVoiceMsg&recorded_id=" + recorded_id+"&type="+type}).then(function (result) {
            $ionicLoading.hide();
            return result.data;
        });
      }  
      
        var _updateSeenMessages = function (id) {
      
         return $http({method: "jsonp", url: AppConstant.ServerPath +"?callback=JSON_CALLBACK&param=updateSeenMessages&id=" + id}).then(function (result) {
            return result.data;
        });
      }  
      
     futurecallFactory.getMessageList = _getMessageList;
     futurecallFactory.getVoiceMsg = _getVoiceMsg;
     futurecallFactory.updateSeenMessages = _updateSeenMessages;
     
    
     
    return futurecallFactory;
});
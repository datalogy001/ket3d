futurecall.controller('callFutureController', function ($scope, $location, AppConstant, $ionicPopup, $ionicHistory, callFutureService,$stateParams,$filter) {

    // Date js
    $('#meetingTime').mobiscroll().time({
        theme: 'mobiscroll',
        lang: 'en',
        display: 'bottom',
        timeFormat: 'HH:ii',
        timeWheels: 'HHii'
   //     rtl:true,
    });

    $('#meetingDate').mobiscroll().date({
        theme: 'mobiscroll',
        lang: 'en',
        display: 'bottom',
        minDate: new Date(),
        maxDate: new Date(2050, 12, 31),
        dateFormat: 'yyyy-mm-dd',
        dateOrder: 'yyyyMMdd',
    });

    $scope.callFutureInit = function ()
    {
        $scope.userListObj = {
            receiver_id: "",
            userTime: "",
            userDate: "",
            userDateTime: "",
            recoredVoiceName: "",
            userName :""
        };
        $scope.callTalk=false;
        $scope.disabledField =false;
        $scope.recordStopBtn=false;
        $scope.stopTimer=true;
        $scope.userList = [];
        $scope.userId=window.localStorage.getItem('user_id');
        $scope.userListObj.receiver_id=($stateParams.friendId == 0) ? "" : $stateParams.friendId;
        var Promise = callFutureService.getUserList($scope.userId);
        Promise.then(function (res) {
            if (res.length > 0)
            {
                $scope.userList = res;
            }
        });
    }
    
    //Record audio file
    $scope.submit = function ()
    {
        //form validation start
       var isValidate= validate_field();
        //form validation end
         if(isValidate == true)
         {
          $scope.callTalk=true;
          $scope.recordStopBtn=true;
          $scope.userName = jQuery.map( $scope.userList, function( n, i ) {
                if(n.user_id == $scope.userListObj.receiver_id)
                {
                    if(n.user_id == $scope.userId)
                   return ( "Myself" );
                   else
                   return ( n.firstName );
               }
                  });
         $scope.userName= $scope.userName.join();
         //Start Record 
         $scope.recordName = Date.now()+'.wav';
         window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, OnFileSystem, failGetFile);   
         callTimerFun(0, 60);
        }   
               
    }
   //End Recorded voice 
   function OnFileSystem(fileSystem)
   {
     fileSystem.root.getFile($scope.recordName,{ create: true, exclusive: false }, function success(entry) {
          if(device.platform=='Android')
              $scope.src =  entry.toURL();
          else
              $scope.src = entry.fullPath;
            
            $scope.mediaRec = new Media($scope.src, function() { }, function(err) {}); 
            $scope.mediaRec.startRecord();
        },
        function fail() {}
    );  
   }
   
   $scope.recordProcess=function()
   {
      $scope.finishRecord = $ionicPopup.confirm({
                title: 'Are you sure you want to stop future call?',
                cancelText: 'No',
                cancelType: 'button',
                okText: 'Yes',
                okType: 'button'
            });
            $scope.finishRecord.then(function (res) {
                if (res) {
                  $scope.stopTimer=false;  
                  $scope.uploadOnServer() ;
                }
            });  
     
   }
   
    function callTimerFun( minutes, seconds )
    {
        var endTime=0, hours=0, mins=0, msLeft=0, time=0;
   
    function twoDigits( n )
    {
        return (n <= 9 ? "0" + n : n);
    }

    function updateTimer()
    {  
        msLeft = endTime - (+new Date);
        if ( msLeft < 1000 ) {
            if($scope.stopTimer==true)
          {
          $scope.uploadOnServer();
          }
        } else {
            time = new Date( msLeft );
            hours = time.getUTCHours();
            mins = time.getUTCMinutes();
           $("#countDownTimer").html((hours ? hours + ':' + twoDigits( mins ) : mins) + ':' + twoDigits( time.getUTCSeconds() )); 
          if($scope.stopTimer==true)
          {
            setTimeout( updateTimer, time.getUTCMilliseconds() + 500 );
          }
        }
    }
    
    endTime = (+new Date) + 1000 * (60*minutes + seconds) + 500;
    updateTimer();
    }
    //Recorder function
    
    $scope.uploadOnServer=function()
    {
    $scope.mediaRec.stopRecord();
    var options = new FileUploadOptions();
    options.fileKey = "file";
    options.fileName = $scope.recordName;
    options.mimeType = "audio/wav";
    options.chunkedMode = false;
    $scope.userListObj.recoredVoiceName= $scope.recordName;
    if(device.platform =="Android")
        $scope.path=$scope.src;
        else
        $scope.path =cordova.file.tempDirectory+$scope.src;
    var ftNew = new FileTransfer();
    ftNew.upload($scope.path, encodeURI(AppConstant.AudioServerPath), winUpload, failUpload, options);  
    }
    
     var winUpload = function (r) {
       //Record added 
       if(r.response == 1)
       {
        var Promise = callFutureService.saveRecordedMsg($scope.userListObj);    
        Promise.then(function (res) {
            if (res.success == 1)
            {
                $scope.filterDate = $filter('date')($scope.userListObj.userDate, "dd-MM-yyyy"); 
                $scope.recordedMessageBox("Message has been sent to "+ $scope.userName+" at "+ $scope.filterDate +" : "+$scope.userListObj.userTime);
            } else
            {
                $scope.errorAlertBoxAll("Please try again !");
            }
        }); 
      }  
    }
     function failGetFile(err){
      $scope.errorAlertBoxAll("Please try again !");
    }
    
     var failUpload = function (error) {
        $scope.errorAlertBoxAll("Please try again !");
    }
    //End Recorder
    
   function validate_field()
   {
       $scope.userListObj.userTime = $("#meetingTime").val();
        $scope.userListObj.userDate = $("#meetingDate").val();
        var dateOne="";
        var dateTwo="";
        //Common codes for both multiple user and indivuals  
           if ($scope.userListObj.receiver_id == "") {
          $scope.errorAlertBoxAll("Please choose friend");
          return false;
           }
         if ($scope.userListObj.userTime == "") {
            $scope.errorAlertBoxAll("Please set time");
            return false;
        }
        if ($scope.userListObj.userDate == "") {
            $scope.errorAlertBoxAll("Please set date");
            return false;
        }
      
        $scope.userListObj.userDateTime = $scope.userListObj.userDate + " " + $scope.userListObj.userTime;
        dateOne = new Date($scope.userListObj.userDateTime);
        dateTwo = new Date();
         if(dateOne < dateTwo )
         {
          $scope.errorAlertBoxAll("Please select valid date and time");
          return false;
         }
         
         return true;
   }
   
    $scope.mergeUserListCallFun=function()
  {
        $scope.selectedUserList= [];
        $('input[name="collectAllUser[]"]:checked').each(function () {
            $scope.selectedUserList.push(this.value);
        });
  }

$scope.callFutureIndvInit = function ()
    {
         $scope.userListObj = {
            receiver_id: "",
            userTime: "",
            userDate: "",
            userDateTime: "",
            recoredVoiceName: "",
            userName :""
        };
        $scope.callTalk=false;
        $scope.disabledField =false;
        $scope.recordStopBtn=false;
        $scope.stopTimer=true;
        $scope.userList = [];
        $scope.userId=window.localStorage.getItem('user_id');
        
        $scope.userListObj.receiver_id=($stateParams.indvFriendId == 0) ? "" : $stateParams.indvFriendId;
        var Promise = callFutureService.getUserList($scope.userId);
        Promise.then(function (res) {
            if (res.length > 0)
            {
                $scope.userList = res;
            }
        });
    }
    
});




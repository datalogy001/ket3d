futurecall.controller('callFutureMultiUserController', function($scope, $location, AppConstant, $ionicPopup, $ionicHistory, callFutureService, $stateParams,$filter) {

    // Date js
    $('#meetingTimeMulti').mobiscroll().time({
        theme: 'mobiscroll',
        lang: 'en',
        display: 'bottom',
        timeFormat: 'HH:ii',
        timeWheels: 'HHii'
                //     rtl:true,
    });

    $('#meetingDateMulti').mobiscroll().date({
        theme: 'mobiscroll',
        lang: 'en',
        display: 'bottom',
        minDate: new Date(),
        maxDate: new Date(2050, 12, 31),
        dateFormat: 'yyyy-mm-dd',
        dateOrder: 'yyyyMMdd',
    });

    $scope.callFutureUserListInit = function()
    {
        $scope.selectedUserList = [];
        $scope.getFromParam = [];
        $scope.mergeUserList = [];
        $scope.userListRes=[];
       
          $scope.userListObj = {
            receiver_id: "",
            userTime: "",
            userDate: "",
            userDateTime: "",
            recoredVoiceName: "",
            userName :""
        };
        $scope.callTalk=false;
        $scope.disabledField =false;
        $scope.recordStopBtn=false;
        $scope.stopTimer=true;
        
        $scope.collectAllUser = [];
        $scope.getFromParam = $stateParams.friendList;
        
        var Promise = callFutureService.getUserListForAll(window.localStorage.getItem('user_id'), $scope.getFromParam);
        Promise.then(function(res) {
            if (res.length > 0)
            {
                $scope.mergeUserList = res;
                angular.forEach(res, function(value, key) {
                    $scope.selectedUserList.push(res[key].user_id);
                });
            }
        });
        //Get user List
        var Promise1 = callFutureService.getUserList(window.localStorage.getItem('user_id'));
        Promise1.then(function (res) {
            if (res.length > 0)
            {
                $scope.userListRes = res;
            }
        });
    }

    $scope.mergeUserListCallFun = function()
    {
        $scope.selectedUserList = [];
        $('input[name="collectAllUser[]"]:checked').each(function() {
            $scope.selectedUserList.push(this.value);
        });
    }
    
     //Record audio file
    $scope.submit = function ()
    {
        $scope.newUserList=[];
        //form validation start
         var isValidate= validate_field();
        //form validation end
         if(isValidate == true)
         {
          $scope.callTalk=true;
          $scope.recordStopBtn=true;
      //Get all user list
     if($scope.selectedUserList.length > 0 )
     {
         for(var k=0; k < $scope.selectedUserList.length;k++)
         {
         isExist($scope.selectedUserList[k],$scope.userListRes);
         }
     }
         
         if($scope.newUserList.length > 1)
         {
             $scope.messagePart= "all";
             $scope.grpUserName=$scope.newUserList.join(", ");
         }
         else
         {
             $scope.messagePart= $scope.newUserList.join();
             $scope.grpUserName=$scope.newUserList.join();
         }
         //Start Record 
         $scope.recordName = Date.now()+'.wav';
          window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, OnFileSystem, failGetFile);   
          callTimerFun(0, 60);
      }   
               
    }
    
    function isExist(userId,userList)
{
  for(var i = 0, len = userList.length; i < len; i++) {
        if( userList[ i ].user_id == userId )
            $scope.newUserList.push(userList[ i ].firstName);
    }
    
}

     function OnFileSystem(fileSystem)
   {
     fileSystem.root.getFile($scope.recordName,{ create: true, exclusive: false }, function success(entry) {
          if(device.platform=='Android')
              $scope.src =  entry.toURL();
          else
              $scope.src = entry.fullPath;
            
            $scope.mediaRec = new Media($scope.src, function() { }, function(err) {}); 
            $scope.mediaRec.startRecord();
        },
        function fail() {}
    );  
   }
    
      $scope.recordProcess=function()
   {
      $scope.finishRecord = $ionicPopup.confirm({
                title: 'Are you sure you want to stop future call?',
                cancelText: 'No',
                cancelType: 'button',
                okText: 'Yes',
                okType: 'button'
            });
            $scope.finishRecord.then(function (res) {
                if (res) {
                  $scope.stopTimer=false;  
                  $scope.mediaRec.stopRecord();
                  $scope.uploadOnServer() ;
                }
            });  
     
   }
   
    function callTimerFun( minutes, seconds )
    {
        var endTime=0, hours=0, mins=0, msLeft=0, time=0;
   
    function twoDigits( n )
    {
        return (n <= 9 ? "0" + n : n);
    }

    function updateTimer()
    {  
        msLeft = endTime - (+new Date);
        if ( msLeft < 1000 ) {
            if($scope.stopTimer==true)
          {
           $scope.uploadOnServer();
       }
        } else {
            time = new Date( msLeft );
            hours = time.getUTCHours();
            mins = time.getUTCMinutes();
           $(".countDownTimer").html((hours ? hours + ':' + twoDigits( mins ) : mins) + ':' + twoDigits( time.getUTCSeconds() )); 
          if($scope.stopTimer==true)
          {
            setTimeout( updateTimer, time.getUTCMilliseconds() + 500 );
          }
        }
    }
    
    endTime = (+new Date) + 1000 * (60*minutes + seconds) + 500;
    updateTimer();
    }
    //Recorder function
    
    $scope.uploadOnServer=function()
    {
    $scope.mediaRec.stopRecord();
    var options = new FileUploadOptions();
    options.fileKey = "file";
    options.fileName = $scope.recordName;
    options.mimeType = "audio/wav";
    options.chunkedMode = false;
    $scope.userListObj.recoredVoiceName= $scope.recordName;
    if(device.platform =="Android")
        $scope.path=$scope.src;
        else
        $scope.path =cordova.file.tempDirectory+$scope.src;
    var ftNew = new FileTransfer();
    ftNew.upload($scope.path, encodeURI(AppConstant.AudioServerPath), winUpload, failUpload, options);  
    }
    
 
     var winUpload = function (r) {
       //Record added 
       if(r.response == 1)
       {
        var Promise = callFutureService.saveRecordedMsgAll($scope.userListObj, $scope.selectedUserList);   
        Promise.then(function (res) {
            if (res.success == 1)
            {
                $scope.filterDate = $filter('date')($scope.userListObj.userDate, "dd-MM-yyyy"); 
                $scope.recordedMessageBox("Message has been sent to "+ $scope.messagePart+" at "+$scope.filterDate+" : "+$scope.userListObj.userTime);
            } else
            {
                $scope.errorAlertBoxAll("Please try again !");
              //  $scope.isDisabled=false;
            }
        }); 
      }  
    }
    
    function failGetFile(err){
      $scope.errorAlertBoxAll("Please try again !");
    }
    
     var failUpload = function (error) {
        $scope.errorAlertBoxAll("Please try again !");
    }
    //End Recorder
    
   function validate_field()
   {
        var dateOne="";
        var dateTwo="";
        $scope.userListObj.userTime = $("#meetingTimeMulti").val();
        $scope.userListObj.userDate = $("#meetingDateMulti").val();

        //Common codes for both multiple user and indivuals  
        if ($scope.selectedUserList.length == 0) {
            $scope.errorAlertBoxAll("Please select atleast one contact person");
            return false;
        }
        if ($scope.userListObj.userTime == "") {
            $scope.errorAlertBoxAll("Please set time");
            return false;
        }
        if ($scope.userListObj.userDate == "") {
            $scope.errorAlertBoxAll("Please set date");
            return false;
        }
        
        $scope.userListObj.userDateTime = $scope.userListObj.userDate + " " + $scope.userListObj.userTime;
        dateOne = new Date($scope.userListObj.userDateTime);
        dateTwo = new Date();
         if(dateOne < dateTwo )
         {
          $scope.errorAlertBoxAll("Please select valid date and time");
          return false;
         }
         
       return true;
   }

});




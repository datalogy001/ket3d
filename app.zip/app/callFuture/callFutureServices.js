futurecall.factory('callFutureService', function ($q, $http,AppConstant,$ionicLoading) {
  var futurecallFactory = {};
    var deferred = $q.defer();
    
      var _getUserList = function (user_id) {
          
         return $http({method: "jsonp", url: AppConstant.ServerPath +"?callback=JSON_CALLBACK&param=getUserList&user_id=" + user_id}).then(function (result) {
          return result.data;
        });
      }    
      
       var _getUserListForAll = function (user_id,userList) {
        $ionicLoading.show({
            content: '<i class="icon ion-loading-a"></i>',
            showBackdrop: false
        });
         return $http({method: "jsonp", url: AppConstant.ServerPath +"?callback=JSON_CALLBACK&param=getUserListForAll&user_id=" + user_id+"&userList="+userList}).then(function (result) {
            $ionicLoading.hide();
            return result.data;
        });
      } 
      
      
       var _saveRecordedMsg = function (res) {
        var user_id= window.localStorage.getItem('user_id');
        $ionicLoading.show({
            content: '<i class="icon ion-loading-a"></i>',
            showBackdrop: false
        });
         return $http({method: "jsonp", url: AppConstant.ServerPath +"?callback=JSON_CALLBACK&param=saveRecordedMsg&recordedData=" + JSON.stringify(res)+"&user_id="+user_id}).then(function (result) {
            $ionicLoading.hide();
            return result.data;
        });
      }   
      
       var _saveRecordedMsgAll = function (res,userList) {
        var user_id= window.localStorage.getItem('user_id');
        $ionicLoading.show({
            content: '<i class="icon ion-loading-a"></i>',
            showBackdrop: false
        });
         return $http({method: "jsonp", url: AppConstant.ServerPath +"?callback=JSON_CALLBACK&param=saveRecordedMsgAll&recordedData=" + JSON.stringify(res)+"&user_id="+user_id+"&userList="+userList}).then(function (result) {
            $ionicLoading.hide();
            return result.data;
        });
      }    
      
    
     futurecallFactory.getUserList = _getUserList;
     futurecallFactory.getUserListForAll = _getUserListForAll;
     futurecallFactory.saveRecordedMsg = _saveRecordedMsg;
     futurecallFactory.saveRecordedMsgAll = _saveRecordedMsgAll;
     
    return futurecallFactory;
});
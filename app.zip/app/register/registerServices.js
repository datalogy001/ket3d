futurecall.factory('registerService', function ($q, $http,AppConstant, $ionicLoading) {
    var futurecallFactory = {};
    var deferred = $q.defer();
    var device_token = '';
    var platform = '';

    var _registerUser = function (registerDetail) {
        
         if (window.localStorage.getItem('device_token_for_push') == null || window.localStorage.getItem('device_token_for_push') == '') {
          device_token = '';  
          platform = '';
        }else{
            device_token = window.localStorage.getItem('device_token_for_push');
            platform = device.platform;
        }
        $ionicLoading.show({
            content: '<i class="icon ion-loading-a"></i>',
            showBackdrop: false
        }); 
        return $http({method: "jsonp", url: AppConstant.ServerPath + "?callback=JSON_CALLBACK&param=registerServiceApi&data=" + JSON.stringify(registerDetail)+ "&device=" + platform + "&device_token=" + device_token}).then(function (result) {
            $ionicLoading.hide();
            return result.data;
        });
    };


    futurecallFactory.registerUser = _registerUser;
    
    return futurecallFactory;
});
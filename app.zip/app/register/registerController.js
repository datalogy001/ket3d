futurecall.controller('registerController', function ($scope,registerService,$location) {
    
    //init variable 
    $scope.registerData = {
        name: "",
        email: "",
        password: "",
        confirm_password:"",
     };
    var emailRegEx = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i; 
   //Register function 
   $scope.register=function()
   {
         if ($scope.registerData.name == "") {
            $scope.errorAlertBoxAll("Please enter your name");
            return false;
        }
        
        if ($scope.registerData.email == "") {
            $scope.errorAlertBoxAll("Please enter your email address");
            return false;
        }
        if (!emailRegEx.test($scope.registerData.email)) {
            $scope.errorAlertBoxAll("Email should be valid");
            return false;
        }

        if ($scope.registerData.password == "") {
            $scope.errorAlertBoxAll("Please enter password");
            return false;
        }
        if ($scope.registerData.password.length < 6) {
            $scope.errorAlertBoxAll("Password must be greater than or equal to six charaters");
            return false;
        }
        
        if ($scope.registerData.confirm_password == "") {
            $scope.errorAlertBoxAll("Please enter confirm  password" );
            return false;
        }
        
        if ($scope.registerData.password != $scope.registerData.confirm_password) {
            $scope.errorAlertBoxAll("Both password did not match");
            return false;
        }
         var Promise;
         Promise = registerService.registerUser($scope.registerData);
      
        Promise.then(function (res) {
            if (res.email_error > 0) {
                $scope.registerData.email="";
                $scope.errorAlertBoxAll("This email already exist");
            }
            if (res.success == 1){
                    $scope.messageBoxAll("Thanks for registering with us");
                   }
        });
    }

});
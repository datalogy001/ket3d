futurecall.controller('loginController', function ($scope,ngFB,loginService, $location,$ionicLoading,xmppService) {
    $scope.loginData = {
        email: "",
        password: ""
    };
    var emailRegEx = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;

    /*Login starts*/
    $scope.login = function () {
        if ($scope.loginData.email == "") {
            $scope.errorAlertBoxAll("Please enter your email address");
            return false;
        }
        if (!emailRegEx.test($scope.loginData.email)) {
            $scope.errorAlertBoxAll("Email should be valid");
            return false;
        }

        if ($scope.loginData.password == "") {
            $scope.errorAlertBoxAll("Please enter password");
            return false;
        }

            var Promise = loginService.loginUser($scope.loginData);
            Promise.then(function (res) {
                if (res.invalid_login == 1) {
                    $scope.loginData = {
                        email: "",
                        password: ""
                    };
                    $scope.errorAlertBoxAll("Invalid login credentials are entered!");
                } else {
                    window.localStorage.setItem('user_id', res.user_id);
                    window.localStorage.setItem('email', res.email);
                    window.localStorage.setItem('firstName', res.firstName);
                    window.localStorage.setItem('chat_id',res.chat_id); 
                    xmppService.login(window.localStorage.getItem('chat_id'), window.localStorage.getItem('chat_id'));
                    $location.url("/main/home");
                      }
            });
    }
    
    /***********************************/
     /* Facebook login start */
    /***********************************/
    $scope.fbLogin=function()
    {
       ngFB.login({scope: 'email'}).then(
                function (response) {
                //    alert(JSON.stringify(response));
                    if (response.status === 'connected') { 
                        //alert(JSON.stringify(response.authResponse.accessToken));
                        $ionicLoading.show({
                            content: '<i class="icon ion-loading-a"></i>',
                            showBackdrop: false
                        });
                        window.localStorage.setItem('fbtoken', response.authResponse.accessToken);
                        $scope.getProfileFacebook();
                    } else {
                       $scope.errorAlertBoxAll("Facebook login failed ");
                    }
                });  
    }
    
    /***********************************/
     /* Facebook login end */
    /***********************************/
     $scope.getProfileFacebook = function () { 
        ngFB.api({
            path: '/me',
            params: {fields: 'id,name,last_name,email,first_name,gender'}
        }).then(
                function (result) {
                 //   alert("res"+JSON.stringify(result)); 
                    if (result.email == '') {
                        $scope.errorAlertBoxAll("Sorry, You have not provided your email info. Please try again ");
                        if (window.localStorage.getItem('fbtoken') != null || window.localStorage.getItem('fbtoken') != '') {
                            $scope.fbLogOut();
                        }
                    }
                    var Promise = loginService.checkFacebookLogin(result);
                    Promise.then(function (res) {
                        if(res.status_error== 0)
                        {
                        window.localStorage.setItem('user_id', res.user_id);
                        window.localStorage.setItem('email', res.email);
                        window.localStorage.setItem('firstName', res.firstname);
                        $location.url("/main/home");    
                        //   window.localStorage.setItem('chat_id',$scope.userDetail.username); 
                        /* if (res.userProfile == 0)
                            {
                              window.localStorage.setItem('profileImage', 'http://graph.facebook.com/' + res.facebook_id + '/picture?width=270&height=270');  
                            } else
                            {
                                window.localStorage.setItem('profileImage', AppConstant.APIPath + AppConstant.serverProfileImagePath + res.userProfile);
                            } */
                        //$scope.getLoggedUser(true);
                       }else
                       {
                         $scope.errorAlertBoxAll("Record not added ,Please try again ");   
                       }
                    
                    });
                },
                function (error) {
                    $scope.errorAlertBoxAll('Facebook error : ' + error.error_description);
                });
    }
    
    
    $scope.fbLogOut = function () {
        ngFB.logout();
    }
    
});
futurecall.factory('loginService', function ($http,AppConstant,$ionicLoading) {
  var futurecallFactory = {};
  var device_token = '';
  var platform = '';
    
      var _loginUser = function (loginDetail) {
          
       /* if (window.localStorage.getItem('device_token_for_push') == null || window.localStorage.getItem('device_token_for_push') == '') {
          device_token = '';  
          platform = '';
        }else{
            device_token = window.localStorage.getItem('device_token_for_push');
            platform = device.platform;
        }*/
          if (window.localStorage.getItem('pushTokenOneSignal') == null || window.localStorage.getItem('pushTokenOneSignal') == '') {
          device_token = '';  
          platform = '';
        }else{
            device_token = window.localStorage.getItem('pushTokenOneSignal');
            platform = device.platform;
        }
        $ionicLoading.show({
            content: '<i class="icon ion-loading-a"></i>',
            showBackdrop: false
        });
         return $http({method: "jsonp", url: AppConstant.ServerPath +"?callback=JSON_CALLBACK&param=loginUserApi&userEmail=" + loginDetail.email + "&userPassword=" + loginDetail.password+ "&device=" + platform + "&device_token=" + device_token}).then(function (result) {
            $ionicLoading.hide();
            return result.data;
        });
      }    
        var _checkFacebookLogin = function (fbloginDetail) {
            
         if (window.localStorage.getItem('device_token_for_push') == null || window.localStorage.getItem('device_token_for_push') == '') {
          device_token = '';  
          platform = '';
        }else{
            device_token = window.localStorage.getItem('device_token_for_push');
            platform = device.platform;
        }
        $ionicLoading.show({
            content: '<i class="icon ion-loading-a"></i>',
            showBackdrop: false
        });
        return $http({method: "jsonp", url: AppConstant.ServerPath + "?callback=JSON_CALLBACK&param=checkFacebook&fbEmail=" + fbloginDetail.email + "&fbid=" + fbloginDetail.id+ "&fname=" + fbloginDetail.first_name+ "&lname=" + fbloginDetail.last_name + "&gender="+fbloginDetail.gender+"&device="+platform+"&device_token="+device_token}).then(function (result) {
            $ionicLoading.hide();
            return result.data;
        });
      }  
      
    
     futurecallFactory.loginUser = _loginUser;
     futurecallFactory.checkFacebookLogin = _checkFacebookLogin;
    return futurecallFactory;
});
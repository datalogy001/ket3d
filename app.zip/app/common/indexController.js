futurecall.controller('indexController', function($scope, commonServices, $location, $ionicPopup, $ionicHistory, $interval, AppConstant, xmppService) {
    /*Error Box*/

//Set user name 

    $scope.chatNotification = "";
    $scope.messageNotification = "";


    $scope.getUserName = function()
    {
        $scope.chatNotification = window.localStorage.getItem('chatNotification');
        $scope.messageNotification = window.localStorage.getItem('msgNotification');

        if (window.localStorage.getItem('firstName') != null)
        {
            $scope.firstName = window.localStorage.getItem('firstName');
        }

    }

//End

    var errorPopup = "";
    $scope.errorAlertBoxAll = function(textData) {
        errorPopup = $ionicPopup.show({
            template: textData,
            title: 'Error',
            buttons: [
                {text: 'ok'},
            ]

        });
    }
    /* success box */
    var successRecoredPopup = "";
    $scope.recordedPopup = function(textData) {
        $ionicPopup.show({
            template: textData,
            title: 'Success',
            buttons: [
                {text: 'ok'},
            ]

        });

    }

    var successRecordPopup = "";
    $scope.recordedMessageBox = function(textData) {
        successRecordPopup = $ionicPopup.show({
            template: textData,
            title: 'Success',
            buttons: [
                {text: 'ok'},
            ]

        });
        successRecordPopup.then(function(res) {
            $location.url("main/home");
        });
    }

    /* success box */
    var successPopup = "";
    $scope.messageBoxAll = function(textData) {
        successPopup = $ionicPopup.show({
            template: textData,
            title: 'Success',
            buttons: [
                {text: 'ok'},
            ]

        });
        successPopup.then(function(res) {
            $location.url("/main/login");
        });
    }

    var successRecordPopup = "";
    $scope.recordedMessageBox = function(textData) {
        successRecordPopup = $ionicPopup.show({
            template: textData,
            title: 'Success',
            buttons: [
                {text: 'ok'},
            ]

        });
        successRecordPopup.then(function(res) {
            $location.url("main/home");
        });
    }

    //Rediredt route


    $scope.redirctRoute = function(routepath)
    {
        $location.url(routepath);
    }
    var exitApp = "";

    $scope.exitApp = function()
    {
        var exitApp = $ionicPopup.confirm({
            title: 'Are you sure you want to exit?',
            cancelText: 'CANCEL',
            cancelType: 'button',
            okText: 'OK',
            okType: 'button'
        });
        exitApp.then(function(res) {
            if (res) {
           //     var promise = commonServices.logOut();
            //    promise.then(function(resLogout) {
               //     if (resLogout.logout == 1) {
                        xmppService.logout();
                        localStorage.clear();
                        $ionicHistory.clearCache();
                        $ionicHistory.clearHistory();
                        $location.url("main/main-screen");
                 //   }
              //  });

            }
        });
    }

    $scope.redirecttohome = function()
    {
        $location.url("main/home");
    }

    //For interval to chat messages 

    if (window.localStorage.getItem('user_id') > 0) {
        var timer = $interval(function() {
            $scope.callIntervalFun();
        }, 2000);

    }

    $scope.callIntervalFun = function() {
        var notificationInfo = commonServices.notificationInfoService(window.localStorage.getItem('user_id'));
        notificationInfo.then(function(result)
        {
            $scope.chatNotification = (result.chatNotificationCnt > 0) ? result.chatNotificationCnt : "";
            window.localStorage.setItem('chatNotification', $scope.chatNotification);
            $scope.messageNotification = (result.msgNotificationCnt > 0) ? result.msgNotificationCnt : "";
            window.localStorage.setItem('msgNotification', $scope.messageNotification);
        });
    }
    /**      social share   ***/

    $scope.social_share = function() {
        window.plugins.socialsharing.share("Future call App is quite interesting ,Please click to following link to download ", null, AppConstant.ShareImagePath + 'share-img.jpg', 'https://play.google.com/store?hl=en');

    }

});




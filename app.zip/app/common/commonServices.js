futurecall.factory('commonServices', function ($q, $http,AppConstant,$ionicLoading) {
  var futurecallFactory = {};
    var deferred = $q.defer();
     
    //chat notification 
     var _notificationInfoService=function(user_id){
        return $http({method: "jsonp", url: AppConstant.ServerPath + "?callback=JSON_CALLBACK&param=notificationInfo&user_id="+ user_id }).then(function (result) {
            return result.data;
        });
    }
     var _logOut = function () {
         var user_id = window.localStorage.getItem('user_id');
        return $http({method: "jsonp", url: AppConstant.ServerPath + "?callback=JSON_CALLBACK&param=logOut&user_id=" + user_id}).then(function (result) {
            return result.data;
        });

        //alert(JSON.stringify($http));
    }
   futurecallFactory.notificationInfoService = _notificationInfoService;
    futurecallFactory.logOut = _logOut;
   
    return futurecallFactory;
});
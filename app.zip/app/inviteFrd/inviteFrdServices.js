futurecall.factory('inviteFrdServices', function ($q, $http,AppConstant,$ionicLoading) {
  var futurecallFactory = {};
    var deferred = $q.defer();
     
    //chat notification 
     var _inviteFriendSubmission=function(frdList){
         
         var userName=window.localStorage.getItem('firstName');
         var user_id=window.localStorage.getItem('user_id');
         var userEmail= window.localStorage.getItem('email');
         
         $ionicLoading.show({
            content: '<i class="icon ion-loading-a"></i>',
            showBackdrop: false
        });
                        
        return $http({method: "jsonp", url: AppConstant.ServerPath + "?callback=JSON_CALLBACK&param=inviteFriendSubmission&frdList="+ JSON.stringify(frdList)+"&userName="+userName +"&user_id="+user_id+"&userEmail="+userEmail }).then(function (result) {
            $ionicLoading.hide();
            return result.data;
        });
    }
    
     var _getUserListInvite = function (user_id) {
        $ionicLoading.show({
            content: '<i class="icon ion-loading-a"></i>',
            showBackdrop: false
        });
         return $http({method: "jsonp", url: AppConstant.ServerPath +"?callback=JSON_CALLBACK&param=getUserListInvite&user_id=" + user_id}).then(function (result) {
            $ionicLoading.hide();
            return result.data;
        });
      } 
      
   futurecallFactory.inviteFriendSubmission = _inviteFriendSubmission;
   futurecallFactory.getUserListInvite = _getUserListInvite;
   
    return futurecallFactory;
});
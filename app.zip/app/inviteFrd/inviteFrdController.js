futurecall.controller('inviteFrdController', function ($scope,inviteFrdServices,callFutureService, $location, $ionicPopup,$ionicHistory,$interval,AppConstant) {

    //Get contact list
    
    $scope.inviteFrdInit=function()
    {
        $scope.frdListObj = {
            email: "",
            user_id: "",
            msg: "",
        };
        $scope.userId=window.localStorage.getItem('user_id');
        $scope.frdList = [];
        var Promise = inviteFrdServices.getUserListInvite($scope.userId);
        Promise.then(function (res) {
            if (res.length > 0)
            {
                $scope.frdList = res;
            }
        });  
    }
    //End 
    
    $scope.inviteFrdSubmit=function()
    {
       var emailRegEx = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
       
         if (($scope.frdListObj.user_id == "") && ($scope.frdListObj.email == "")) {
            $scope.errorAlertBoxAll("Please select one of the option");
            return false;
        }
       if ((!emailRegEx.test($scope.frdListObj.email)) && ($scope.frdListObj.email != "") ){
            $scope.errorAlertBoxAll("Email should be valid");
            return false;
        }
        
        if (($scope.frdListObj.user_id > 0) &&($scope.frdListObj.email != "")) {
              $scope.frdListObj.email= "";
              $scope.frdListObj.user_id= "";
              $scope.errorAlertBoxAll("Please choose only one option");
            return false;
        }
        
        if ($scope.frdListObj.msg == "") {
            $scope.errorAlertBoxAll("Please enter message");
            return false;
        }
       //Invite friend functionality started 
        var Promise = inviteFrdServices.inviteFriendSubmission($scope.frdListObj);
        Promise.then(function (res) {
           
            if (res.success == true)
            {
                $scope.recordedMessageBox("Mail sent successfully");
            } else
            {
                $scope.errorAlertBoxAll("Please try again!");
            }
        });
       
       //End 
       

    }
});




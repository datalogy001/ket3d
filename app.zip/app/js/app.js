var futurecall = angular.module('futurecall', ['ionic', 'ngOpenFB', 'tabSlideBox', 'monospaced.elastic', 'ionicLazyLoad']);
futurecall.run(function($ionicPlatform, $location, $ionicPopup, ngFB, xmppService) {
    //Check whether login or not
    if (window.localStorage.getItem('user_id') > 0)
    {
        $location.url("main/home");
    } else
    {
        $location.url("main/main-screen");
    }


    // H/w back button  
    $ionicPlatform.registerBackButtonAction(function(event) {
        if ($location.path() === '/main/main-screen') {
            var exitApp = $ionicPopup.confirm({
                title: 'Are you sure you want to exit?',
                cancelText: 'CANCEL',
                cancelType: 'button',
                okText: 'OK',
                okType: 'button'
            });
            exitApp.then(function(res) {
                if (res) {
                    ionic.Platform.exitApp();
                }
            });
        } else if ($location.path() === '/main/home')
        {
            var exitApp = $ionicPopup.confirm({
                title: 'Are you sure you want to exit?',
                cancelText: 'CANCEL',
                cancelType: 'button',
                okText: 'OK',
                okType: 'button'
            });
            exitApp.then(function(res) {
                if (res) {
                    ionic.Platform.exitApp();
                }
            });
        }
        else
        {
            navigator.app.backHistory();
        }
    }, 100);

    //132234127213599
    ngFB.init({appId: '132234127213599'});
    $ionicPlatform.ready(function() {
   //For Push notification      

      /* var notificationOpenedCallback = function(jsonData) {
            //if false means we are inside app
            if(jsonData.isActive == false)
            {
            if (jsonData.additionalData.success == true)
            {
                if (window.localStorage.getItem('user_id') > 0)
                {
                    $location.url("main/chat/"+jsonData.additionalData.otherUserId);
                } else
                {
                    $location.url("main/main-screen");
                }
            }
          }
        };

        window.plugins.OneSignal.init("5383b9a2-820b-4791-a62b-a1109b715e4d",
                {googleProjectNumber: "1091996744363"},
        notificationOpenedCallback);
        //Get User onesignal ID

        window.plugins.OneSignal.getIds(function(ids) {
            window.localStorage.setItem("pushTokenOneSignal", ids.userId);
        }); */

        // Show an alert box if a notification comes in when the user is in your app.
      //  window.plugins.OneSignal.enableInAppAlertNotification(false);

        //End
        // Check for network connection
        if (window.Connection) {
            if (navigator.connection.type == Connection.NONE) {
                $ionicPopup.alert({
                    title: 'No Internet Connection <br />Please try again.',
                    buttons: [{
                            text: 'OK',
                            type: 'button',
                            onTap: function() {
                                ionic.Platform.exitApp();
                            }
                        }]
                });
            }
        }
        //End
        /* For chat */
        if (window.localStorage.getItem('chat_id') != null) { //alert(window.localStorage.getItem('chat_id'));
            xmppService.login(window.localStorage.getItem('chat_id'), window.localStorage.getItem('chat_id'));

        }
        /*End */

        if (window.cordova && window.cordova.plugins.Keyboard) {
            // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
            // for form inputs)
            cordova.plugins.Keyboard.hideKeyboardAccessoryBar(false);
            // Don't remove this line unless you know what you are doing. It stops the viewport
            // from snapping when text inputs are focused. Ionic handles this internally for
            // a much nicer keyboard experience.
            cordova.plugins.Keyboard.disableScroll(true);
        }

    });
});

var isLive = true; //  for live make it true
var debugMode = (!isLive) ? "http://192.168.1.44:8081/futurecall/app/" : "http://product-demo.com:8081/futurecall/app/";
var rootPath = (!isLive) ? "http://192.168.1.44:8081/futurecall/chatImages/" : "http://product-demo.com:8081/futurecall/chatImages/";
var apiMode = (!isLive) ? "http://192.168.1.44:8081/futurecall/api-serverfiles/api_8Aug.php" : "http://product-demo.com:8081/futurecall/api-serverfiles/api_8Aug.php";
var shareImagePath = (!isLive) ? "http://192.168.1.44:8081/futurecall/api-serverfiles/shareImage/" : "http://product-demo.com:8081/futurecall/api-serverfiles/shareImage/";
var audioServerPath = (!isLive) ? "http://192.168.1.44:8081/futurecall/api-serverfiles/uploadAudio.php" : "http://product-demo.com:8081/futurecall/api-serverfiles/uploadAudio.php";
var audioFolderPath = (!isLive) ? "http://192.168.1.44:8081/futurecall/RecoredVoiceMessages/" : "http://product-demo.com:8081/futurecall/RecoredVoiceMessages/";

futurecall.constant('AppConstant', {
    ServerPath: apiMode,
    AudioServerPath: audioServerPath,
    AudioFolderPath: audioFolderPath,
    RootPath: rootPath,
    ShareImagePath: shareImagePath,
    //Important 
    //Please check chat application with live mode 
    //Server address may be changed  http://get-site-ip.com/
    chatserver: "@product-demo.com",
    xmppconnregister: "product-demo.com",
    xmppAuth: (!isLive) ? "http://192.168.1.44:5280/http-bind" : "http://49.248.53.154:5280/http-bind",
    //   groupchatserver: "@conference.http://192.168.1.44"
});

futurecall.config(function($stateProvider, $urlRouterProvider) {
    $stateProvider
            .state('main', {
                url: '/main',
                cache: false,
                templateUrl: 'menu/menu.html',
                abstract: true,
                controller: 'indexController'
            })
            .state('main.main-screen', {
                url: "/main-screen",
                cache: false,
                views: {
                    'main': {
                        templateUrl: "common/main-screen.html",
                        controller: 'indexController'
                    }
                }
            })
            .state('main.login', {
                url: "/login",
                cache: false,
                views: {
                    'main': {
                        templateUrl: "login/login.html",
                        controller: 'loginController'
                    }
                }
            })
            .state('main.home', {
                url: "/home",
                cache: false,
                views: {
                    'main': {
                        templateUrl: "home/homepage.html",
                        controller: 'indexController'
                    }
                }
            })
            .state('main.inviteFriend', {
                url: "/inviteFriend",
                cache: false,
                views: {
                    'main': {
                        templateUrl:  "inviteFrd/invite-friend.html",
                        controller: 'inviteFrdController'
                    }
                }
            })
            .state('main.contactPerson', {
                url: "/contactPerson",
                cache: false,
                views: {
                    'main': {
                        templateUrl:  "contacts/contact-persons.html",
                        controller: 'contactController'
                    }
                }
            })
            .state('main.chat', {
                url: "/chat/:chat_user_id",
                cache: false,
                views: {
                    'main': {
                        templateUrl:  "chat/chat.html",
                        controller: 'chatController'
                    }
                }
            })
            .state('main.callFuture', {
                url: "/callFuture/:friendId",
                cache: false,
                views: {
                    'main': {
                        templateUrl: "callFuture/callFuture.html",
                        controller: 'callFutureController'
                    }
                }
            })

            .state('main.callFutureIndv', {
                url: "/callFutureIndv/:indvFriendId",
                cache: false,
                views: {
                    'main': {
                        templateUrl: "callFuture/callFutureIndv.html",
                        controller: 'callFutureController'
                    }
                }
            })

            .state('main.callFutureUserList', {
                url: "/callFutureUserList/:friendList",
                cache: false,
                views: {
                    'main': {
                        templateUrl:  "callFuture/callFutureUserList.html",
                        controller: 'callFutureMultiUserController'
                    }
                }
            })

            .state('main.messageList', {
                url: "/messageList/:userMsgList",
                cache: false,
                views: {
                    'main': {
                        templateUrl:  "message/messageList.html",
                        controller: 'messageController'
                    }
                }
            })

            .state('main.contactMessageList', {
                url: "/contactMessageList/:contactMsgList",
                cache: false,
                views: {
                    'main': {
                        templateUrl:  "message/contact-messageList.html",
                        controller: 'messageController'
                    }
                }
            })

            .state('main.voiceMsg', {
                url: "/voiceMsg/:recordMsgId/:type",
                cache: false,
                views: {
                    'main': {
                        templateUrl:  "message/voiceMessage.html",
                        controller: 'messageController'
                    }
                }
            })

            .state('main.register', {
                url: "/register",
                cache: false,
                views: {
                    'main': {
                        templateUrl: "register/register.html",
                        controller: 'registerController'
                    }
                }
            });

    $urlRouterProvider.otherwise('main/main-screen');
})


futurecall.factory('chatService', function ($q, $http,AppConstant,$ionicLoading) {
  var futurecallFactory = {};
    var deferred = $q.defer();
    
      var _getAllChatmsg = function (participant_id) {
        var user_id = window.localStorage.getItem("user_id"); 
       
        return $http({method: "jsonp", url: AppConstant.ServerPath + "?callback=JSON_CALLBACK&param=getAllChatmsg&user_id="+user_id+'&participant_id='+participant_id}).then(function (result) {
            return result.data;
        });
    }
    
    var _getuserDetail = function (participant_id) {
        return $http({method: "jsonp", url: AppConstant.ServerPath + "?callback=JSON_CALLBACK&param=getuserDetail&participant_id="+participant_id}).then(function (result) {
            return result.data;
        });
    }
    var _getAddUpdateStatus = function (to) {
        var from = window.localStorage.getItem("user_id"); 
       
        return $http({method: "jsonp", url: AppConstant.ServerPath + "?callback=JSON_CALLBACK&param=getAddUpdateStatus&user_id="+from+'&participant_id='+to}).then(function (result) {
            return result.data;
        });
    }
     var _changedOnlineStatus = function (to) {
        var from = window.localStorage.getItem("user_id"); 
       
        return $http({method: "jsonp", url: AppConstant.ServerPath + "?callback=JSON_CALLBACK&param=changedOnlineStatus&user_id="+from+'&participant_id='+to}).then(function (result) {
            return result.data;
        });
    }
    var _getprevChatmsg = function (participant_id,id) {
        var user_id = window.localStorage.getItem("user_id");
        return $http({method: "jsonp", url: AppConstant.ServerPath + "?callback=JSON_CALLBACK&param=getprevChatmsg&user_id="+user_id+'&participant_id='+participant_id+'&id='+id}).then(function (result) {
            return result.data;
        });
    }
   futurecallFactory.getAllChatmsg = _getAllChatmsg;
   futurecallFactory.getuserDetail = _getuserDetail;
   futurecallFactory.getprevChatmsg = _getprevChatmsg;
   futurecallFactory.getAddUpdateStatus = _getAddUpdateStatus;
   futurecallFactory.changedOnlineStatus = _changedOnlineStatus;
   

   
    return futurecallFactory;
});
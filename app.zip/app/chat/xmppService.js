futurecall.service('xmppService', function (AppConstant, $timeout, $q, $http, $rootScope) {
    var conn = new Strophe.Connection(AppConstant.xmppAuth);
    return {
        login: login,
        sendFriendRequest: sendFriendRequest,
        send_message: send_message,
        logout: logout,
        checkUserpresence: checkUserpresence,
        sendXmppRequest: sendXmppRequest,
        declineFriendRequest: declineFriendRequest,
        enterGroupChat: enterGroupChat,
        send_group_message: send_group_message,
        
    }


    function login(u_id, password) { 
        conn.connect(u_id + AppConstant.chatserver, password, OnConnectionStatus);
    }

    function OnConnectionStatus(nStatus) { //alert("connection"+nStatus); //alert("Strophe"+Strophe.Status);
        if (nStatus == Strophe.Status.ERROR) {
       //     alert("Unknown Error Occured");
        } else if (nStatus == Strophe.Status.CONNECTED) {
            $timeout(function () {
                connected();
            }, 0);
        } else if (nStatus == Strophe.Status.AUTHFAIL) {
          //  alert("Authentication Failure. Please check username and password");
        } else if (nStatus == Strophe.Status.DISCONNECTED) {
            var timer = setInterval(function () {
                var user = window.localStorage.getItem('chat_id');
                var pass = window.localStorage.getItem('chat_id');
                if (conn.connected == false && pass != null) {
                    login(user, pass);
                } else {
                    clearInterval(timer);
                }
            }, 3000);
        }
    }

//register handlers
    function connected() { 
        //To check connection of xampp server
       // console.log("xmpp connected");
       // 
        //get all the friends from friends list
        conn.roster.get(get_friends, 0);
        //handle when someone sends us a friend requests
        conn.addHandler(subscribeStanza, null, "presence", "subscribe");
        //when someone accepts our friend request
        conn.addHandler(subscribedStanza, null, "presence", "subscribed");
        //someone who had earlier accepted your friend request now removed you from their contact list 
        conn.addHandler(unsubscribeStanza, null, "presence", "unsubscribe");
        //handle when user comes online
        conn.addHandler(status_changed_available, null, "presence");
        //handle when user comes online
        conn.addHandler(status_changed_unavailable, null, "presence", "unavailable");
        //******handle when someone sends us a message
        conn.addHandler(message_received, null, "message", "chat");
        //send your status to all other users.
        conn.send($pres());
        //handle when someone sends us a message
        conn.addHandler(group_chat_message_received, null, "message", "groupchat");
    }

    function sendFriendRequest(to_id) {
        var user_id = window.localStorage.getItem("user_id");
        return $http({method: "jsonp", url: AppConstant.ServerPath + "?callback=JSON_CALLBACK&param=sendFriendRequest&user_id=" + user_id + '&to=' + to_id}).then(function (result) {
            return result.data;
        });
    }



    function get_friends(items) {
       // console.log("my friends" + JSON.stringify(items));
        var myfriends = [];
        for (var count = 0; count < items.length; count++) {
             (items[count].subscription == 'both')?myfriends.push(items[count].jid):'';
        }
      //  console.log(">>>>" + JSON.stringify(myfriends));
        /*if (items != undefined) {
            if (items.length != 0) {
                var html_friends_list = "";
                var html_message_boxes = "";
                for (var count = 0; count < items.length; count++) {
                    if (items[count].subscription == "both") {
                        var display_name = Strophe.getNodeFromJid(items[count].jid);
                        html_friends_list = html_friends_list + "<li id='open_chat_box_list_item" + items[count].jid + "'>" + "<a href='javascript:open_chat_box(\"" + items[count].jid + "\")'>" + display_name + "<span class='block-list-label' id='" + items[count].jid + "_unread_messages" + "'>0</span><span class='block-list-label' id='" + items[count].jid + "_change_status" + "'></span></a></li>";
                        html_message_boxes = html_message_boxes + '<div style="display: none" class="grid-block small-12 medium-12 vertical" id="';
                        html_message_boxes = html_message_boxes + items[count].jid + '_message_box"><div class="grid-content">';
                        html_message_boxes = html_message_boxes + '<div id="' + items[count].jid + 'message_box_text' + '">';
                        html_message_boxes = html_message_boxes + '</div>';
                        html_message_boxes = html_message_boxes + '</div><div class="message-input grid-content collapse shrink"><span class="inline-label">';
                        html_message_boxes = html_message_boxes + '<input type="text" id="' + items[count].jid + "_input" + '" placeholder="Message"><a href="#" class="button" onclick="send_message(\'' + items[count].jid + '\')">Send</a>';
                        html_message_boxes = html_message_boxes + '</span></div></div>';
                    }
                }

                // document.getElementById("message_boxes").innerHTML = html_message_boxes;
                // document.getElementById("friends-list").innerHTML = html_friends_list;
            }
        }*/
    }

    var online_users = [];
    function status_changed_unavailable(stanza) {
       // alert("bye"+"OFFLINE"+JSON.stringify(stanza));
        try {
            var from = $(stanza).attr('from');
            var type = $(stanza).attr('type');
            var jid = Strophe.getBareJidFromJid(from);
            if (jid != Strophe.getBareJidFromJid(conn.jid)) {

                /* Multi User Chat Presense */

                var conference = from.indexOf("@conference.product-demo.com");
                if (conference > -1) {
                    var muc_name = Strophe.getNodeFromJid(from);
                    var muc_person_name = from.split("/")[1];
                 //   alert(muc_person_name + " has left group '" + muc_name + "'");
                    return true;
                }

                /* Multi User Chat Presense Ends */

                var index = online_users.indexOf(jid);
                if (index > -1) {
                    online_users.splice(index, 1);
                }

                index = online_users.indexOf(jid);
                if (index > -1) {
                    //alert(jid + "-------->online");
                    // document.getElementById(jid + "_change_status").innerHTML = "&#9635;&nbsp;&nbsp;";
                } else {
                    //alert(jid + "-------->offline");
                    // document.getElementById(jid + "_change_status").innerHTML = "";
                }
            }
        }
        catch (e) {
        }


        return true;
    }

    function status_changed_available(stanza) {
        try {
            var from = $(stanza).attr('from');
            var type = $(stanza).attr('type');
            var jid = Strophe.getBareJidFromJid(from);
             
            if (jid != Strophe.getBareJidFromJid(conn.jid)) {
                 
             //    alert("type"+type+">>>"+jid) ;
                /* Multi User Chat Presense */

                var conference = from.indexOf("@conference.product-demo.com");
                if (conference > -1) {
                    var muc_name = Strophe.getNodeFromJid(from);
                    var muc_person_name = from.split("/")[1];
                    if (type == undefined) {
                     //   alert(muc_person_name + " has joined group '" + muc_name + "'");
                    }
                    return true;
                }

                /* Multi User Chat Presense Ends */

                if (type == undefined) {
                    online_users[online_users.length] = jid;                    
                }
            }
        }
        catch (e) {
            console.log(e);
        }


        return true;
    }

    function subscribeStanza(stanza) {

        var from_id = stanza.getAttribute("from");
        //have u already sent subscribe
        var item = conn.roster.findItem(from_id);
        if (item != false) {
            if (item.subscription == "to") {
                conn.send($pres({to: from_id, type: "subscribed"}));
                return true;
            }
        }
        confirmFriendRequest(from_id);
        return true;
    }

    function sendXmppRequest(toxmpp_id) {
        conn.send($pres({to: toxmpp_id + AppConstant.chatserver, type: "subscribe"}));
    }

    function confirmFriendRequest(id) {
        conn.send($pres({to: id, type: "subscribed"}));
        conn.send($pres({to: id, type: "subscribe"}));
    }

    function declineFriendRequest(id) {
        conn.send($pres({to: id, type: "unsubscribed"}));
    }

    function subscribedStanza(stanza) {
        var from_id = stanza.getAttribute("from");
        console.log("You and " + from_id + " are now friends");
        return true;
    }

    function unsubscribeStanza(stanza) {
        var from_id = stanza.getAttribute("from");
        conn.send($pres({to: from_id, type: "unsubscribe"}));
        console.log("You and " + from_id + " are not friends anymore");
        return true;
    }

    function checkUserpresence(to) {
        //To set your initial presence:
        //alert(to);
        conn.send($pres());
        var check = $pres({type: 'probe', to: to + AppConstant.chatserver});
      //  alert(check);
        conn.send(check);
      //  alert("--------- viewed ------>" + conn.send(check));
    }


    function message_received(stanza) { 
        var from = $(stanza).attr('from');
        var type = $(stanza).attr('type');
        var jid = Strophe.getBareJidFromJid(from);
        var str = jid.split("@"); 
        var body = $(stanza).find('body').text(); 
        var arr = body.split(">><<~*~**~*~>><<"); 
        if (arr[0] != '' || arr[1] != '') {
            $rootScope.$broadcast('incomingMessage', {incomingdata: {image: arr[0], text: arr[1], user: str[0]}});
        }
        return true;
    }


    function send_message(to, text, image,from,deviceId,loginUserName) {      
        var message = $msg({to: to + AppConstant.chatserver, from: conn.jid, type: "chat"}).c("body").t(image + ">><<~*~**~*~>><<" + text);
        conn.send(message.tree());
        return $http({method: "jsonp", url: AppConstant.ServerPath + "?callback=JSON_CALLBACK&param=saveChat&user_id=" + from + '&chatimage=' + image + '&chatmsg=' + encodeURIComponent(text) + '&to=' + to+"&deviceId="+deviceId+"&loginUserName="+loginUserName}).then(function (result) {
        });
    }

    function enterGroupChat(name) {
        var o = {to: name + "@conference.product-demo.com" + "/" + Strophe.getNodeFromJid(conn.jid), from: conn.jid};
        var m = $pres(o);
        m.c('x', {xmlns: 'http://jabber.org/protocol/muc#user'}, null);
        conn.send(m.tree());
        return true;
    }
    
    

    function send_group_message(name, text, image, fromuser, fromuserimage) {
        console.log("groupmsg sent----->");
        var o = {to: name + "@conference.product-demo.com", type: 'groupchat', from: conn.jid};
        var m = $msg(o);
        m.c('body', null, image + ">><<~*~**~*~>><<" + text + ">><<~*~**~*~>><<" + fromuser + ">><<~*~**~*~>><<" + fromuserimage);
        conn.send(m.tree());

        var user_id = window.localStorage.getItem("user_id");
        return $http({method: "jsonp", url: AppConstant.ServerPath + "?callback=JSON_CALLBACK&param=saveGroupChat&user_id=" + user_id + '&chatimage=' + image + '&chatmsg=' + encodeURIComponent(text) + '&group_id=' + name}).then(function (result) {
        });
    }

    function group_chat_message_received(stanza) {

        var from = $(stanza).attr('from');
        var group_name = Strophe.getNodeFromJid(from);
        from = from.split("/")[1];
        var body = $(stanza).find('body').text();
        var arr = body.split(">><<~*~**~*~>><<");

        if (body) {
            $rootScope.$broadcast('incomingGroupMessage', {incomingdata: {image: arr[0], text: arr[1], username: arr[2], user_img: arr[3], user: from}});
        }

        return true;
    }

    function logout() {
        conn.disconnect();
        conn.flush();
    }

});
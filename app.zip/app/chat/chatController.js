futurecall.controller('chatController', function ($scope,$ionicLoading,AppConstant,$ionicActionSheet,$location,$ionicModal, $ionicPopup,xmppService,$ionicHistory,$ionicScrollDelegate,chatService,$ionicSideMenuDelegate,$stateParams,$timeout) {
 
$ionicSideMenuDelegate.canDragContent(false);

$scope.user_id = window.localStorage.getItem('user_id');
$scope.nickname=window.localStorage.getItem('firstName');


$scope.msgData = {
        txt: "",
    };
$scope.imgCaption = {
        txt: "",
};
$scope.user_img = "";
var OneonOneMesgs = null;
$scope.allMessages = [];
$scope.myChatid = window.localStorage.getItem('chat_id');
var txtInput, footerBar, scroller;
         
        $scope.$on('$ionicView.enter', function () {
        //Add online status   
        var prom1 = chatService.getAddUpdateStatus($stateParams.chat_user_id);
        $timeout(function () {
            txtInput = angular.element(document.querySelector('.chat-footer textarea'));
            footerBar = document.body.querySelector('#userMessagesView .bar-footer');
             scroller = angular.element(document.querySelector('#userMessagesView .scroll-content'));
        }, 1);
        
           $timeout(function () {
           $ionicScrollDelegate.scrollBottom(true); 
        }, 500); 
    });
        
       $scope.$on('$ionicView.leave', function () {
         //Update online status   
         var prom2 = chatService.changedOnlineStatus($stateParams.chat_user_id);
           });
           
      $scope.sendMessage = function(to) { 
        keepKeyboardOpen();
        var text = ($scope.imgCaption.txt == '') ? $scope.msgData.txt : $scope.imgCaption.txt;
        var img = ($scope.sendImgData == undefined) ? '' : $scope.sendImgData;
        xmppService.send_message(to, text, img ,$scope.user_id ,$scope.other_device_id ,window.localStorage.getItem('firstName') );
   
        $scope.allMessages.push({
            chatid: window.localStorage.getItem('chat_id'),
            chatmsg: text,
            chat_img: (img != '') ?  img : '',
            chat_date: new Date()
        });
        
        $timeout(function () {
           $ionicScrollDelegate.scrollBottom(true); 
        }, 300);
        
        $scope.msgData.txt = '';
        $scope.imgCaption.txt = '';
        $scope.sendImgData = '';
        $scope.sendImgUrl = '';
       
    };


    $scope.getMessages = function () { 
        
        $scope.imageUrl=AppConstant.RootPath;
        if ($stateParams.chat_user_id != 'undefined' && $stateParams.chat_user_id != '') {

            var prom = chatService.getAllChatmsg($stateParams.chat_user_id);
            prom.then(function(res) {
                $scope.allMessages = res; 
              //  console.log(JSON.stringify($scope.allMessages));
                OneonOneMesgs = res;
                (res[0] != undefined)?$scope.prevchatid = res[0].id:$scope.prevchatid ='';
                if (res.length > 9) {
                    $scope.infiniteScrollPrevent = false;
                } else {
                    $scope.infiniteScrollPrevent = true;
                }

             $timeout(function () {
                    $ionicScrollDelegate.scrollBottom();
                }, 2000); 
            });
        }
    };
    
   
     $scope.loadMorePrevChat = function () {
        var scrollBefore = document.getElementById('userMessagesView').scrollHeight;
        if ($scope.infiniteScrollPrevent == false) {
            var prom = chatService.getprevChatmsg($stateParams.chat_user_id, $scope.prevchatid);
            prom.then(function (res) {
                $scope.allMessages = res;
                if (res.length > 9) {
                    $scope.infiniteScrollPrevent = false;
                    (res[0]!= undefined)?$scope.prevchatid = res[0].id:$scope.prevchatid ='';
                    $scope.allMessages = $scope.allMessages.concat(OneonOneMesgs);
                    OneonOneMesgs = $scope.allMessages;
                } else {
                    
                    $scope.allMessages = $scope.allMessages.concat(OneonOneMesgs);
                   // console.log("msg"+JSON.stringify($scope.allMessages));
                    $timeout(function () {
                        $scope.infiniteScrollPrevent = true;
                    }, 2000); 
                }
                $scope.$broadcast('scroll.refreshComplete');
                $timeout(function () {
                    var scrollAfter = document.getElementById('userMessagesView').scrollHeight;
                    $ionicScrollDelegate.scrollTo(0, scrollAfter - scrollBefore, false);
                }, 1);
            });
            // hide loading icon
        } else {
            $scope.$broadcast('scroll.refreshComplete');
        }

    }

    /*****************************************************************************/

    // get the chat participant name and username (xmpp)
    $scope.userDetail  = function () {
        $scope.other_device_id="";
        if ($stateParams.chat_user_id != 'undefined' && $stateParams.chat_user_id != '') {
            var chatusername = chatService.getuserDetail($stateParams.chat_user_id);
            chatusername.then(function(res) {   
                 $timeout(function () {
                    $scope.other_chat_id = res.chat_user_id; 
                    $scope.other_device_id=res.deviceId;
                    xmppService.checkUserpresence($scope.other_chat_id);
                    $scope.chat_user_name = res.nickname; 
                }, 800);
            });
            
        }
    };
   
    $scope.$on('incomingMessage', function (event, data) {
        //alert("xxxx--" + data.incomingdata.image)
        $scope.allMessages.push({
            chatid: data.incomingdata.user,
            chatmsg: data.incomingdata.text,
            chat_img: (data.incomingdata.image != '') ? data.incomingdata.image : '',
            chat_date: new Date()
        });
        //$ionicScrollDelegate.scrollBottom(true);
        $timeout(function () {
            $ionicScrollDelegate.scrollBottom(true);
        }, 300);
    });
    

    function keepKeyboardOpen() { 
        txtInput.one('blur', function () {
            txtInput[0].focus();
        });
    }
    
     $scope.SendImageChat = function () {
        // Show the action sheet
        var hideSheet = $ionicActionSheet.show({
            buttons: [
                {text: '<i class="ion-ios-camera android-i"></i> Camera'},
                {text: '<i class="ion-images android-i"></i> Photo Library'}
            ],
            titleText: 'Send Image',
            cancelText: 'Cancel',
            cancel: function () {
                // add cancel code..
            },
            buttonClicked: function (index) {
                (index == 0) ? sendImageFromCamera() : sendImageFromLibrary();
                return true;
            }
        });
    }
    
     function sendImageFromCamera() {
        var options = {
            quality: 80,
            saveToPhotoAlbum: true,
            allowEdit: false,
            correctOrientation: true,
            destinationType: Camera.DestinationType.FILE_URI,
            sourceType: 1, // 0:Photo Library, 1=Camera, 2=Saved Photo Album
            encodingType: 0     // 0=JPG 1=PNG
        }
        navigator.camera.getPicture(onSuccess, onFail, options);
    }
    
     function sendImageFromLibrary() {
        var options = {
            quality: 80,
            allowEdit: false,
            correctOrientation: true,
            destinationType: Camera.DestinationType.FILE_URI,
            sourceType: 0, // 0:Photo Library, 1=Camera, 2=Saved Photo Album
            encodingType: 0     // 0=JPG 1=PNG
        }
        navigator.camera.getPicture(onSuccess, onFail, options);
    }
      var onSuccess = function (FILE_URI) {
        uploadChatImg(FILE_URI);
    };
    var onFail = function (e) {
        console.log("On fail " + e);
    };
    var uploadChatImg = function (myImg) {
        $ionicLoading.show({
            content: '<i class="icon ion-loading-a"></i>',
            showBackdrop: false
        });
        var options = new FileUploadOptions();
        options.fileKey = "file";
        options.chunkedMode = false;
        var params = {};
        params.user_id = window.localStorage.getItem('user_id');
        params.friend_id = $stateParams.chat_user_id;
        options.params = params;
        var ft = new FileTransfer();
        ft.upload(myImg, AppConstant.ServerPath + "?callback=JSON_CALLBACK&param=uploadChatImageApi", uploadChatImgSuccess, uploadChatImgFail, options);
    }
    
    
     $scope.openUploadImageModal = function () {
        $ionicLoading.hide();
        $ionicModal.fromTemplateUrl('chat/chat_image.html', {
            scope: $scope,
            animation: 'slide-in-up'
        }).then(function (modal) {
            $scope.modal = modal;
            $scope.modal.show();
        });
    };
    $scope.closeModal = function () {
        $scope.sendImgUrl = '';
        $scope.sendImgData = '';
        $scope.modal.remove();
    };
    
    var uploadChatImgSuccess = function (e) {
       
        if (e.response != 0) {
            $scope.sendImgUrl = AppConstant.RootPath + e.response;
            $scope.sendImgData = e.response;
            //open model for images for add captions
            $scope.openUploadImageModal();
        }
        $ionicLoading.hide();
    }

    var uploadChatImgFail = function (e) {
        $ionicLoading.hide();
    }

   /*  goto see upload picture page */
   // $scope.goPrevious = function(){
     //   window.history.back();
   // }
   
    //zoom images 
   $scope.bigData = '';
    $scope.openZoomModal = function (src) {
        $scope.bigData = src;
        $ionicModal.fromTemplateUrl('chat/big_image.html', {
            scope: $scope,
            animation: 'slide-in-up',
            cache: false
        }).then(function (modal) {
            $scope.Zoommodal = modal;
        });
        $timeout(function () {
            $scope.Zoommodal.show();
        }, 100);

    };
    $scope.closeZoomModal = function () {

        $scope.bigData = '';
        $scope.Zoommodal.hide();
        $scope.Zoommodal.remove();

    };
  
});



